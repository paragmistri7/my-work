import React from 'react';
import UsecontextAPI03 from './33 usecontext03 ';

const UsecontextAPI02  = () => {
    return (
        <>
            <UsecontextAPI03/>
        </>
    );
};

export default UsecontextAPI02;