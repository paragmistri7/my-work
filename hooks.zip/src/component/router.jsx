import React from 'react';
import { Route, Routes } from 'react-router-dom';
import Statefunction01 from './03statefunction';
import UsecontextAPI from './31 usecontextAPI ';
import Useeffect from './35 useeffect ';
import UseParam01 from './38 useParam';
import Usecallback01 from './45 usecallback01 ';
import Usememos from './47 usememo ';
import Navbar from './navbar ';


const Router01 = () => {
    return (
        <>
            <Routes>
                <Route path='/' element={<Navbar />} >
                   <Route path ="usememo" element={ <Usememos/>} />
                   <Route path ="usecallback" element={ <Usecallback01/>} />
                   <Route path ="usecontext" element={ <UsecontextAPI/>} />
                   <Route path ="useeffect" element={ <Useeffect/>} />
                   <Route path ="useparam" element={ <UseParam01/>} />
                   <Route path ="usestate" element={ <Statefunction01/>} />
                </Route>               
            </Routes>
        </>
    );
};

export default Router01;