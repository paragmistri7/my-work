
import React, { useState } from 'react';
import {
  MDBNavbar,
  MDBNavbarNav,
  MDBNavbarItem,
  MDBNavbarLink,
  MDBNavbarToggler,
  MDBContainer,
  MDBIcon,
  MDBCollapse,
  MDBBtn
} from 'mdb-react-ui-kit';
import { Outlet } from 'react-router-dom';

const Navbar = () => {
  
  const [showBasic, setShowBasic] = useState(false);

  return (
<>
    <header>
    
      <div
        className='p-5 text-center bg-image'
        style={{ backgroundImage: "url('https://mdbootstrap.com/img/new/slides/041.webp')", height: '400px' }}
      >
        <div className='mask' style={{ backgroundColor: 'rgba(0, 0, 0, 0.6)' }}> 
          <div className='d-flex justify-content-center align-items-center h-100'>
            <div className='text-white'>
              <h1 className='mb-3 text-light' >React-hook</h1>
                <div className="container  d-flex justify-content-between ">
                  
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="usememo" >Usememo</MDBNavbarLink>
                  </div>
                  
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="usecallback" >Usecallback</MDBNavbarLink>
              </div>
               
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="usecontext" >Usecontext</MDBNavbarLink>
              </div>
               
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="useeffect" >Useeffect</MDBNavbarLink>
              </div>
               
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="useparam" >Useparam</MDBNavbarLink>
              </div>
               
                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="usestate" >Usestate</MDBNavbarLink>
                  </div>
                  
              </div>

                <div className="col">
                <MDBNavbarLink className='text-light fs-4' href="cssadd" >Add CSS</MDBNavbarLink>
              </div>
               
                  

                
            
              
             
             
            </div>
          </div>
        </div>
      </div>
    </header>

      <div className="container text-center my-5">

    <Outlet/>
      </div>
    </>
  );
}


export default Navbar;
